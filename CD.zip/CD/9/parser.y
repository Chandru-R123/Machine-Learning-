
%{
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int temp=1;

char* newtemp()
{
    char *t=(char*)malloc(10);
    sprintf(t,"t%d",temp++);
    return t;
}

void yyerror(char *s);
int yylex();
%}

%union{
char *str;
}

%token <str> ID NUM
%type <str> expr term factor

%%

stmt : ID '=' expr ';'
      {
        printf("%s = %s\n",$1,$3);
      }
     ;

expr : expr '+' term
      {
        char *t=newtemp();
        printf("%s = %s + %s\n",t,$1,$3);
        $$=t;
      }
     | expr '-' term
      {
        char *t=newtemp();
        printf("%s = %s - %s\n",t,$1,$3);
        $$=t;
      }
     | term
      {
        $$=$1;
      }
     ;

term : term '*' factor
      {
        char *t=newtemp();
        printf("%s = %s * %s\n",t,$1,$3);
        $$=t;
      }
     | term '/' factor
      {
        char *t=newtemp();
        printf("%s = %s / %s\n",t,$1,$3);
        $$=t;
      }
     | factor
      {
        $$=$1;
      }
     ;

factor : '(' expr ')'
       {
        $$=$2;
       }
       | ID
       {
        $$=$1;
       }
       | NUM
       {
        $$=$1;
       }
       ;

%%

void yyerror(char *s)
{
printf("Error\n");
}

int main()
{
printf("Enter expression:\n");
yyparse();
return 0;
}