#include <stdio.h>
#include <string.h>

#define MAX_TAC 10
#define MAX_LEN 50

int main() {
    int n;
    printf("=== THREE-ADDRESS CODE TO 8086 ASSEMBLY ===\n");
    printf("Enter number of TAC statements (max 10): ");
    scanf("%d", &n);
    getchar(); // consume newline once

    char tac[MAX_TAC][MAX_LEN];

    for(int i = 0; i < n; i++) {
        printf("Enter TAC statement %d: ", i+1);
        fgets(tac[i], MAX_LEN, stdin);
        tac[i][strcspn(tac[i], "\n")] = 0;
    }

    printf("\nGenerated 8086 Assembly:\n");

    for(int i = 0; i < n; i++) {
        char lhs[10], rhs[30];

        // split LHS and RHS properly
        sscanf(tac[i], "%[^=]=%[^\n]", lhs, rhs);

        // remove spaces
        char *l = lhs;
        while(*l == ' ') l++;
        char *r = rhs;
        while(*r == ' ') r++;

        char var1[10], var2[10];
        char op;

        // check for binary operation
        if(sscanf(r, "%s %c %s", var1, &op, var2) == 3) {
            printf("MOV AX, %s\n", var1);

            switch(op) {
                case '+': printf("ADD AX, %s\n", var2); break;
                case '-': printf("SUB AX, %s\n", var2); break;
                case '*': printf("MUL %s\n", var2); break;
                case '/': printf("DIV %s\n", var2); break;
            }

            printf("MOV %s, AX\n", l);
        }
        else {
            // simple assignment
            printf("MOV %s, %s\n", l, r);
        }
    }

    return 0;
}
