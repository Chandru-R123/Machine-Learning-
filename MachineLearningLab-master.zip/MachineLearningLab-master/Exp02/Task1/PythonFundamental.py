name = "Kavi"
age = 21
cgpa = 8.7
is_student = True

print("Name:", name)
print("Age:", age)
print("CGPA:", cgpa)
print("Is Student:", is_student)

print(type(name))
print(type(age))
print(type(cgpa))
print(type(is_student))

num1 = int(input("Enter first number: "))
num2 = int(input("Enter second number: "))

sum = num1 + num2
print("Sum =", sum)
